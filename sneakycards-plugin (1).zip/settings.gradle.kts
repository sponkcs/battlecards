rootProject.name = "sneakycards"
