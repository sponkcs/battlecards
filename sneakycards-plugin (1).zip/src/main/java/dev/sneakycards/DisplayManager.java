package dev.sneakycards;

import com.destroystokyo.paper.profile.ProfileProperty;
import io.papermc.paper.datacomponent.item.ResolvableProfile;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Cards in play. Each placed card is an ItemDisplay lying flat, a Mannequin hovering above it
 * (skin + outer layers), an Interaction hitbox, a health label, and a TextDisplay preview that only
 * the player looking at the card can see. Also plays the move animations and damage popups.
 */
public final class DisplayManager {
    enum Anim { NONE, LUNGE, DASH, SPIN, BOUNCE, HURT }

    static final class Placed {
        final UUID owner; final Card card; final Location base; final float yaw;
        ItemDisplay face; Interaction hit; Mannequin man; TextDisplay preview, hpText;
        Anim anim = Anim.NONE; int animTick = 0; long age = 0;
        // battle state
        int hp, maxHp; boolean ko = false;
        Mat mat; int side = -1, col = -1;
        // attack animation state
        Vector dir; double reach = 1.0; Placed target; Runnable onImpact, onDone;
        Placed(UUID owner, Card card, Location base, float yaw) { this.owner = owner; this.card = card; this.base = base; this.yaw = yaw; }
    }

    private final SneakyCardsPlugin plugin;
    private final List<Placed> placed = new ArrayList<>();
    private final Map<UUID, Placed> byEntity = new HashMap<>();
    private final Map<UUID, Placed> viewing = new HashMap<>();
    private int ticks = 0;

    DisplayManager(SneakyCardsPlugin plugin) { this.plugin = plugin; }

    void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            tick();
            if (++ticks % 4 == 0) updatePreviews();
        }, 1L, 1L);
    }

    // ---- placing and removing ----

    public Placed place(Player owner, Card card, Location top, float yaw) {
        int max = plugin.getConfig().getInt("max-cards-per-player", 3);
        long mine = placed.stream().filter(p -> p.owner.equals(owner.getUniqueId())).count();
        if (mine >= max) {
            owner.sendMessage(Component.text("You can only have " + max + " cards in play.", NamedTextColor.RED));
            return null;
        }
        World w = top.getWorld();
        Placed p = new Placed(owner.getUniqueId(), card, top.clone(), yaw);
        p.maxHp = card.stat(Stat.HEALTH);
        p.hp = p.maxHp;
        ItemStack item = plugin.items().card(card);
        double hover = plugin.getConfig().getDouble("hover-height", 0.6);
        double scale = plugin.getConfig().getDouble("mannequin-scale", 0.45);

        p.face = w.spawn(top.clone().add(0, 0.03, 0), ItemDisplay.class, d -> {
            d.setItemStack(item);
            d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            d.setRotation(yaw, 0);
            // Lays the card flat. Tune angle/scale on your server if it looks mirrored.
            d.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f((float) Math.toRadians(-90), 1, 0, 0),
                    new Vector3f(1.7f, 1.7f, 1.7f), new AxisAngle4f()));
            d.setPersistent(false);
        });
        p.hit = w.spawn(top.clone(), Interaction.class, i -> {
            i.setInteractionWidth(1.1f);
            i.setInteractionHeight(1.5f);
            i.setResponsive(true);
            i.setPersistent(false);
        });
        ResolvableProfile profile = profile(card);
        Location manLoc = top.clone().add(0, hover, 0);
        manLoc.setYaw(yaw);
        p.man = w.spawn(manLoc, Mannequin.class, m -> {
            m.setProfile(profile);
            m.setImmovable(true);
            m.setGravity(false);
            m.setInvulnerable(true);
            m.setSilent(true);
            m.setPersistent(false);
            m.setDescription(null);
            m.setCustomNameVisible(false);
            AttributeInstance sc = m.getAttribute(Attribute.SCALE);
            if (sc != null) sc.setBaseValue(scale);
        });
        p.hpText = w.spawn(top.clone().add(0, 1.75, 0), TextDisplay.class, t -> {
            t.text(hpLine(p));
            t.setBillboard(Display.Billboard.CENTER);
            t.setBackgroundColor(Color.fromARGB(120, 10, 10, 16));
            t.setPersistent(false);
            t.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(0.6f, 0.6f, 0.6f), new AxisAngle4f()));
        });
        p.preview = w.spawn(top.clone().add(0, 2.2, 0), TextDisplay.class, t -> {
            t.text(previewText(card));
            t.setBillboard(Display.Billboard.CENTER);
            t.setBackgroundColor(Color.fromARGB(170, 15, 15, 20));
            t.setLineWidth(240);
            t.setVisibleByDefault(false);
            t.setPersistent(false);
            t.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(0.7f, 0.7f, 0.7f), new AxisAngle4f()));
        });
        placed.add(p);
        byEntity.put(p.hit.getUniqueId(), p);
        byEntity.put(p.man.getUniqueId(), p);
        return p;
    }

    private ResolvableProfile profile(Card c) {
        var b = ResolvableProfile.resolvableProfile();
        String s = c.skin();
        if (s.equalsIgnoreCase("placeholder")) s = plugin.getConfig().getString("placeholder-skin", "Steve");
        if (s.startsWith("http")) {
            String json = "{\"textures\":{\"SKIN\":{\"url\":\"" + s + "\"}}}";
            String value = Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));
            b.uuid(UUID.nameUUIDFromBytes(s.getBytes(StandardCharsets.UTF_8)));
            b.addProperty(new ProfileProperty("textures", value));
        } else {
            b.name(s); // the server resolves the username
        }
        return b.build();
    }

    private Component previewText(Card c) {
        var b = Component.text();
        b.append(Component.text(c.name(), c.rarity().color()).decorate(TextDecoration.BOLD)).appendNewline();
        b.append(Component.text(c.rarity().label + "  ", c.rarity().color()))
                .append(Component.text(c.collection(), NamedTextColor.GRAY).decorate(TextDecoration.ITALIC)).appendNewline();
        b.append(Component.text(c.background().label, NamedTextColor.DARK_GRAY)).appendNewline();
        for (Stat s : Stat.values()) b.append(Component.text(s.label + " " + c.stat(s), NamedTextColor.WHITE)).appendNewline();
        for (Move m : c.moves())
            b.append(Component.text(m.name() + "  " + m.stat().label + " " + c.power(m), NamedTextColor.YELLOW)).appendNewline();
        return b.build();
    }

    private Component hpLine(Placed p) {
        Component name = Component.text(p.card.name(), p.card.rarity().color());
        if (p.ko) return name.appendNewline().append(Component.text("Knocked out", NamedTextColor.RED));
        double r = p.hp / (double) Math.max(1, p.maxHp);
        int filled = (int) Math.ceil(r * 10);
        NamedTextColor c = r > 0.5 ? NamedTextColor.GREEN : r > 0.25 ? NamedTextColor.YELLOW : NamedTextColor.RED;
        return name.appendNewline()
                .append(Component.text("❤ " + p.hp + "/" + p.maxHp + " ", c))
                .append(Component.text("█".repeat(filled), c))
                .append(Component.text("█".repeat(10 - filled), NamedTextColor.DARK_GRAY));
    }

    public void refreshHp(Placed p) { if (p.hpText != null && p.hpText.isValid()) p.hpText.text(hpLine(p)); }

    public Placed byEntity(UUID id) { return byEntity.get(id); }

    public void remove(Placed p) {
        p.onImpact = null; p.onDone = null;
        for (Entity e : new Entity[]{p.face, p.hit, p.man, p.preview, p.hpText}) if (e != null) { byEntity.remove(e.getUniqueId()); e.remove(); }
        viewing.values().removeIf(v -> v == p);
        placed.remove(p);
    }

    public void clearOwner(UUID owner) { new ArrayList<>(placed).stream().filter(p -> p.owner.equals(owner)).forEach(this::remove); }
    public void clearAll() { new ArrayList<>(placed).forEach(this::remove); }

    public Placed nearestOwned(Player pl) {
        Placed best = null; double bd = 100;
        for (Placed p : placed) {
            if (!p.owner.equals(pl.getUniqueId()) || !p.base.getWorld().equals(pl.getWorld())) continue;
            double d = p.base.distanceSquared(pl.getLocation());
            if (d < bd) { bd = d; best = p; }
        }
        return best;
    }

    // ---- battle effects ----

    /** Makes the attacker play its move toward the target. onImpact runs at the hit frame, onDone when the animation ends. */
    public void attack(Placed att, Placed tgt, Move move, Runnable onImpact, Runnable onDone) {
        Vector to = tgt.base.toVector().subtract(att.base.toVector());
        to.setY(0);
        double dist = Math.max(0.01, to.length());
        att.dir = to.normalize();
        att.reach = Math.max(1.0, dist * 0.5 / 1.1);
        att.target = tgt;
        att.onImpact = onImpact;
        att.onDone = onDone;
        att.anim = animFor(move);
        att.animTick = 0;
    }

    private static Anim animFor(Move move) {
        return switch (move.stat()) {
            case STRENGTH -> Anim.LUNGE;
            case DEXTERITY -> Anim.DASH;
            case MAGICING -> Anim.SPIN;
            default -> Anim.BOUNCE;
        };
    }

    /** Plain animation without a target (used by /cardadmin move). */
    public void play(Placed p, Move move) {
        p.anim = animFor(move);
        p.animTick = 0;
        Player owner = Bukkit.getPlayer(p.owner);
        if (owner != null) owner.sendActionBar(Component.text(p.card.name() + " uses " + move.name() + "!", p.card.rarity().color()));
    }

    public void hurt(Placed p) { p.anim = Anim.HURT; p.animTick = 0; }

    public void knockOut(Placed p) {
        p.ko = true;
        World w = p.base.getWorld();
        Location l = p.base.clone().add(0, 0.9, 0);
        w.spawnParticle(Particle.LARGE_SMOKE, l, 18, 0.25, 0.4, 0.25, 0.02);
        w.playSound(l, Sound.ENTITY_PLAYER_DEATH, 0.7f, 1.2f);
        if (p.man != null) { byEntity.remove(p.man.getUniqueId()); p.man.remove(); p.man = null; }
        if (p.face != null) p.face.setBrightness(new Display.Brightness(1, 1));
        p.anim = Anim.NONE;
        refreshHp(p);
    }

    /** Floating number that rises and fades away. */
    public void popup(Location at, Component text) {
        TextDisplay t = at.getWorld().spawn(at, TextDisplay.class, d -> {
            d.text(text);
            d.setBillboard(Display.Billboard.CENTER);
            d.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            d.setSeeThrough(true);
            d.setPersistent(false);
        });
        new BukkitRunnable() {
            int n = 0;
            @Override public void run() {
                if (++n > 26 || !t.isValid()) { t.remove(); cancel(); return; }
                t.teleport(t.getLocation().add(0, 0.04, 0));
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    // ---- animation loop ----

    private static Vector forward(float yaw) {
        double r = Math.toRadians(yaw);
        return new Vector(-Math.sin(r), 0, Math.cos(r));
    }

    private static int hitFrame(Anim a) {
        return switch (a) { case LUNGE -> 9; case DASH -> 7; case SPIN -> 12; case BOUNCE -> 10; default -> -1; };
    }

    private void tick() {
        double hover = plugin.getConfig().getDouble("hover-height", 0.6);
        for (Placed p : new ArrayList<>(placed)) {
            if (p.man == null || !p.man.isValid()) continue;
            p.age++;
            double up = hover + Math.sin(p.age * 0.12) * 0.06, fwd = 0, side = 0;
            float yawAdd = 0;
            int a = p.animTick;
            if (p.anim != Anim.NONE) {
                boolean done = false;
                switch (p.anim) {
                    case LUNGE -> { fwd = (a < 5 ? -0.25 * a / 5.0 : a < 9 ? -0.25 + 1.35 * (a - 5) / 4.0 : 1.1 * (1 - (a - 9) / 7.0)) * p.reach; done = a >= 16; }
                    case DASH -> { fwd = Math.sin(a / 14.0 * Math.PI) * 0.7 * Math.min(p.reach, 1.6); side = Math.sin(a / 14.0 * Math.PI * 2) * 0.6; done = a >= 14; }
                    case SPIN -> { up += Math.sin(a / 24.0 * Math.PI) * 0.7; yawAdd = a * 30f; done = a >= 24; }
                    case BOUNCE -> { up += Math.abs(Math.sin(a / 20.0 * Math.PI * 2)) * 0.5; done = a >= 20; }
                    case HURT -> { side = Math.sin(a * 2.5) * 0.12 * (1 - a / 10.0); done = a >= 10; }
                    default -> { }
                }
                p.animTick++;
                Vector f = p.dir != null ? p.dir : forward(p.yaw), r = new Vector(-f.getZ(), 0, f.getX());
                Location l = p.base.clone().add(f.clone().multiply(fwd)).add(r.multiply(side)).add(0, up, 0);
                l.setYaw(p.yaw + yawAdd); l.setPitch(0);
                p.man.teleport(l);
                effects(p, l, f, a);
                if (p.onImpact != null && a == hitFrame(p.anim)) { Runnable run = p.onImpact; p.onImpact = null; run.run(); }
                if (done) {
                    p.anim = Anim.NONE; p.dir = null; p.reach = 1.0; p.target = null;
                    Runnable run = p.onDone; p.onDone = null;
                    if (run != null) run.run();
                }
            } else if (p.age % 2 == 0) {
                Location l = p.base.clone().add(0, up, 0);
                l.setYaw(p.yaw); l.setPitch(0);
                p.man.teleport(l);
            }
        }
    }

    private void beam(Location from, Location to, Particle particle) {
        World w = from.getWorld();
        for (int i = 0; i <= 10; i++) {
            double t = i / 10.0;
            w.spawnParticle(particle, from.clone().add(to.clone().subtract(from).toVector().multiply(t)), 1, 0, 0, 0, 0);
        }
    }

    private void effects(Placed p, Location l, Vector f, int a) {
        World w = l.getWorld();
        Location at = p.target != null ? p.target.base.clone().add(0, 0.9, 0) : l.clone().add(f.clone().multiply(0.6)).add(0, 0.8, 0);
        switch (p.anim) {
            case LUNGE -> {
                if (a == 9) {
                    w.spawnParticle(Particle.SWEEP_ATTACK, at, 1);
                    w.spawnParticle(Particle.CRIT, at, 12, 0.3, 0.3, 0.3, 0.2);
                    w.playSound(at, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 1f);
                }
            }
            case DASH -> {
                if (a % 2 == 0) w.spawnParticle(Particle.CLOUD, l.clone().add(0, 0.3, 0), 3, 0.15, 0.1, 0.15, 0.01);
                if (a == 7) {
                    w.spawnParticle(Particle.CRIT, at, 14, 0.3, 0.3, 0.3, 0.25);
                    w.playSound(at, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 1.3f);
                }
            }
            case SPIN -> {
                w.spawnParticle(Particle.ENCHANT, l.clone().add(0, 0.8, 0), 6, 0.5, 0.6, 0.5, 0.4);
                if (a == 12) {
                    beam(l.clone().add(0, 0.9, 0), at, Particle.END_ROD);
                    w.spawnParticle(Particle.END_ROD, at, 15, 0.3, 0.5, 0.3, 0.05);
                    w.playSound(at, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.2f);
                }
            }
            case BOUNCE -> {
                if (a == 5) w.spawnParticle(Particle.HAPPY_VILLAGER, l.clone().add(0, 0.8, 0), 8, 0.4, 0.4, 0.4, 0);
                if (a == 10) {
                    beam(l.clone().add(0, 0.9, 0), at, Particle.HAPPY_VILLAGER);
                    w.spawnParticle(Particle.HAPPY_VILLAGER, at, 12, 0.4, 0.4, 0.4, 0);
                    w.playSound(at, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 0.8f);
                }
            }
            case HURT -> {
                if (a == 0) {
                    w.spawnParticle(Particle.DAMAGE_INDICATOR, l.clone().add(0, 0.8, 0), 6, 0.3, 0.4, 0.3, 0.1);
                    w.playSound(l, Sound.ENTITY_PLAYER_HURT, 0.8f, 1f);
                }
            }
            default -> { }
        }
    }

    // ---- look-at preview ----

    private void updatePreviews() {
        for (Player pl : Bukkit.getOnlinePlayers()) {
            Entity e = pl.getTargetEntity(6);
            Placed want = e == null ? null : byEntity.get(e.getUniqueId());
            Placed cur = viewing.get(pl.getUniqueId());
            if (cur == want) continue;
            if (cur != null && cur.preview != null) pl.hideEntity(plugin, cur.preview);
            if (want != null && want.preview != null) { pl.showEntity(plugin, want.preview); viewing.put(pl.getUniqueId(), want); }
            else viewing.remove(pl.getUniqueId());
        }
    }
}
